// src/App.js
import React from 'react';
import Home from './Home'; // Home bileşenini import et

function App() {
  return (
    <div>
      <Home /> {/* Home bileşenini burada render ediyoruz */}
    </div>
  );
}

export default App;
